/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.lab2practical;

/**
 *
 * @author nmsaf
 */
public class LibraryManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Library library = new Library();

        // Adding books to the library
       Book book1 = new Book("The Lord of the Rings", "J.R.R. Tolkien") {};
        Book book2 = new Book("Harry Potter and the Philosopher's Stone", "J.K. Rowling") {};
        Book book3 = new Book("Sapiens: A Brief History of Humankind", "Yuval Noah Harari") {};

        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);

        // Checking out a book
        book1.checkOut();

        // Searching for books
        Book foundBookByTitle = library.findBookByTitle("harry potter and the philosopher's stone");
        Book foundBookByAuthor = library.findBookByAuthor("Yuval Noah Harari");

        // Printing book information
        if (foundBookByTitle != null) {
            System.out.println("Found book by title: " + foundBookByTitle.getTitle());
            System.out.println("Author: " + foundBookByTitle.getAuthor());
            System.out.println("Checked out: " + foundBookByTitle.isCheckedOut());
        } else {
            System.out.println("Book not found by title.");
        }

        if (foundBookByAuthor != null) {
            System.out.println("Found book by author: " + foundBookByAuthor.getTitle());
            System.out.println("Author: " + foundBookByAuthor.getAuthor());
            System.out.println("Checked out: " + foundBookByAuthor.isCheckedOut());
        } else {
            System.out.println("Book not found by author.");
        }
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lab2;

/**
 *
 * @author nmsaf
 */
public abstract class BankAccount {
    private final String accountNumber;
    private double balance;
    
    // constructor to set the balance
    
    public BankAccount(String accountNumber){
        this.accountNumber = accountNumber;
        this.balance = 0.0;
    }
    // method to deposit the money to account
    
    public void deposit(double amount){
        if (amount <= 0){
            throw new IllegalArgumentException("Amount to deposit must be greater than 0.");
        }
        balance += amount;
    }
    // method to withdraw the money
    
     public void withdraw(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount to withdraw must be greater than 0.");
        }
        if (amount > balance) {
            throw new IllegalArgumentException("Insufficient balance.");
        }
        balance -= amount;
    }
     // method to display the account details
     
    public void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }
    // getter for the account balance
    
    public double getBalance() {
        return balance;
    }
    
    // Getter for account number
    
    public String getAccountNumber() {
        return accountNumber;
    }

    // Abstract method for displaying additional account information
    
    public abstract void displayAdditionalInfo();
    
}

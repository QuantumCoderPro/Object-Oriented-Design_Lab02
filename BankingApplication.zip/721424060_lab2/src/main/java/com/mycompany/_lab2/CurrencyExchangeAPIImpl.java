/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lab2;

import java.util.Random;

/**
 *
 * @author nmsaf
 */
public class CurrencyExchangeAPIImpl implements CurrencyExchangeAPI{
    
    // fetching exchange rate from external API
    @Override
    public double getExchangeRate(String sourceCurrency, String targetCurrency){
        
        // random exchange rate between 0.5 and 1.0
        double minRate = 0.5;
        double maxRate = 1.0;
        Random random = new Random();
        return minRate + (maxRate-minRate)*random.nextDouble();
    }
    
}

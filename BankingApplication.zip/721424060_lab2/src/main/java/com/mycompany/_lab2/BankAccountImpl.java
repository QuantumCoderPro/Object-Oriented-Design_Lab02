/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lab2;

/**
 *
 * @author nmsaf
 */
// concrete class that extends bank account

public class BankAccountImpl extends BankAccount {
    private double totalDeposits; // To keep track of the total deposit amount
    private double totalWithdrawals; // To keep track of the total withdrawal amount

    public BankAccountImpl(String accountNumber) {
        super(accountNumber);
        this.totalDeposits = 0.0;
        this.totalWithdrawals = 0.0;
    }

    // Override the deposit method to update totalDeposits
    @Override
    public void deposit(double amount) {
        super.deposit(amount);
        totalDeposits += amount;
    }

    // Override the withdraw method to update totalWithdrawals
    @Override
    public void withdraw(double amount) {
        super.withdraw(amount);
        totalWithdrawals += amount;
    }

    // Implementation of the abstract method in the BankAccount class
    @Override
    public void displayAdditionalInfo() {
        // Add any additional information related to the account here
        System.out.println("This is a valid bank account.");
        System.out.println("Total Deposits: " + totalDeposits);
        System.out.println("Total Withdrawals: " + totalWithdrawals);
    }

    // Getter methods for totalDeposits and totalWithdrawals
    public double getTotalDeposits() {
        return totalDeposits;
    }

    public double getTotalWithdrawals() {
        return totalWithdrawals;
    }
}


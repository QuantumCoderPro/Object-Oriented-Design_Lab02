/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany._lab2;

/**
 *
 * @author nmsaf
 */
public class BankingApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BankAccountImpl bankAccount = new BankAccountImpl("2001564158963211");
        CurrencyExchangeAPIImpl exchangeAPI = new CurrencyExchangeAPIImpl();
        
        // deposit and withdraw money
        bankAccount.deposit(20000);
        bankAccount.withdraw(5500);
        bankAccount.deposit(5000);
        bankAccount.withdraw(3500);
        
        // display account details
        bankAccount.displayAccountInfo();
        bankAccount.displayAdditionalInfo();
        
        // get exchange rate and convert amount
        double exchangeRate = exchangeAPI.getExchangeRate("Rupees","USD");
        double convertedAmount = bankAccount.getBalance()* exchangeRate;
        System.out.println("Converted amount from Rupees to USD is:" +convertedAmount);
        
    }
    
    
}

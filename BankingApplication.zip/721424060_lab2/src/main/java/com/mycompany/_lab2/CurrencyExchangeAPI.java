/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany._lab2;

/**
 *
 * @author nmsaf
 */
public interface CurrencyExchangeAPI {
    
    // method to fetch and converting amount to sourcecurrency to target currency
    double getExchangeRate(String sourceCurrency, String targetCurrency);
    
}
